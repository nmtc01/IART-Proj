package heuristic;
import java.util.ArrayList;

public interface Heuristic {

    int getValue(ArrayList<ArrayList<Integer>> board);

}
